package andrew.powersuits.tileentity;

import net.minecraft.tileentity.TileEntity;

/**
 * Created by Eximius88 on 2/4/14.
 */
public class TileEntityPortal extends TileEntity {

    public TileEntityPortal() {

    }
}
