/**
 * 
 */
package net.machinemuse.powersuits.block;

import net.minecraft.tileentity.TileEntity;

/**
 * @author MachineMuse
 * 
 */
public class TileEntityTinkerTable extends TileEntity {

}
