package net.machinemuse.powersuits.control;

import net.minecraft.entity.player.EntityPlayer;

public class ToggleControl implements IBindableControl {

	@Override
	public void onActivate(EntityPlayer player) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onDeactivate(EntityPlayer player) {
		// TODO Auto-generated method stub

	}

}
