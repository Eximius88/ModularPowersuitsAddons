package net.machinemuse.powersuits.item

import net.minecraft.item.ItemArmor

/**
 * Author: MachineMuse (Claire Semple)
 * Created: 8:09 PM, 4/23/13
 */
trait CustomRenderArmorBase extends ItemArmor with ModularItemBase {

}
