package net.machinemuse.powersuits.item

import net.minecraft.item.Item

/**
 * Author: MachineMuse (Claire Semple)
 * Created: 7:29 PM, 5/13/13
 */
class ItemMagic(id:Int) extends Item(id:Int) {

}
