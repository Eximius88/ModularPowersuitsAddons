package net.machinemuse.api.moduletrigger;

import net.machinemuse.api.IPowerModule;

public interface IToggleableModule extends IPowerModule {

}
