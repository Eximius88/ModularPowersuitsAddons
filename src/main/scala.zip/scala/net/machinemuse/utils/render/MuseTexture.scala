package net.machinemuse.utils.render

/**
 * Author: MachineMuse (Claire Semple)
 * Created: 6:28 PM, 5/15/13
 */
class MuseTexture {

}
