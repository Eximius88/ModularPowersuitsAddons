package net.machinemuse.numina.item

import net.minecraft.item.Item

/**
 * Author: MachineMuse (Claire Semple)
 * Created: 12:48 PM, 11/7/13
 */
object JSONItemBase extends Item(ItemIDAllocator.getIDFor("All Components", 1234)) {

}
