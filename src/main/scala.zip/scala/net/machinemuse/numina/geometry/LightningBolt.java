package net.machinemuse.numina.geometry;

import java.nio.DoubleBuffer;

public class LightningBolt {
    public DoubleBuffer points;

    public LightningBolt(double x1, double y1, double z1, double x2, double y2, double z2, double displacement, double detail) {

    }
}
